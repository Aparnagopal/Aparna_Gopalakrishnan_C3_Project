import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

public class Restaurant {
    private String name;
    private String location;
    public LocalTime openingTime;
    public LocalTime closingTime;
    private List<Item> menu = new ArrayList<Item>();

    public Restaurant(String name, String location, LocalTime openingTime, LocalTime closingTime) {
        this.name = name;
        this.location = location;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
    }

    public boolean isRestaurantOpen() {
        boolean isOpen = false;
        int openTimeGT = LocalTime.now().compareTo(openingTime);
        int closeTimeLs = LocalTime.now().compareTo(closingTime);

        if (openTimeGT > 0 && closeTimeLs < 0 ) {
            isOpen = true;
        }
        return isOpen;
        //DELETE ABOVE STATEMENT AND WRITE CODE HERE
    }

    public LocalTime getCurrentTime(){ return  LocalTime.now(); }

    public List<Item> getMenu() {

         return (menu);
        //DELETE ABOVE RETURN STATEMENT AND WRITE CODE HERE
    }

    private Item findItemByName(String itemName){
        for(Item item: menu) {
            if(item.getName().equals(itemName))
                return item;
        }
        return null;
    }

    public void addToMenu(String name, int price) {
        Item newItem = new Item(name,price);
        menu.add(newItem);
    }
    
    public void removeFromMenu(String itemName) throws itemNotFoundException {

        Item itemToBeRemoved = findItemByName(itemName);
        if (itemToBeRemoved == null)
            throw new itemNotFoundException(itemName);

        menu.remove(itemToBeRemoved);
    }
    public void displayDetails(){
        System.out.println("Restaurant:"+ name + "\n"
                +"Location:"+ location + "\n"
                +"Opening time:"+ openingTime +"\n"
                +"Closing time:"+ closingTime +"\n"
                +"Menu:"+"\n"+getMenu());

    }

    public String getName() {
        return name;
    }

    public int getOrderCost(String item1, String item2) {
        int itemOrderCost = 0;
        for (int i = 0; i < menu.size(); i++) {

            if (menu.get(i).getName().equals(item1)) {
                itemOrderCost += menu.get(i).getPrice();
            }
        }
        for (int j = 0; j < menu.size(); j++) {
            // if (restaurants.get(i).getName().equals (restaurantName))
            if (menu.get(j).getName().equals(item1)) {
                itemOrderCost += menu.get(j).getPrice();
            }
        }
        return itemOrderCost;
    }
}


